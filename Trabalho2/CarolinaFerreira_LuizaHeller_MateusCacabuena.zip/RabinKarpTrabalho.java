public class RabinKarpTrabalho {
  public final static int d = 10;

  static void search(String pat, String txt, int q)
    {
        int M = pat.length();
        int N = txt.length();
        int i, j;
        int p = 0;
        int t = 0;
        int h = 1;
 
        for (i = 0; i < M - 1; i++)
            h = (h * d) % q;
 
        for (i = 0; i < M; i++) {
            p = (d * p + pat.charAt(i)) % q;
            t = (d * t + txt.charAt(i)) % q;
        }
 
        for (i = 0; i <= N - M; i++) {
 
            if (p == t) {
                for (j = 0; j < M; j++) {
                    if (txt.charAt(i + j) != pat.charAt(j))
                        break;
                }
 
                if (j == M)
                    System.out.println(
                        "Pattern found at index " + i);
            }
 
            if (i < N - M) {
                t = (d * (t - txt.charAt(i) * h)
                     + txt.charAt(i + M))
                    % q;
 
                if (t < 0)
                    t = (t + q);
            }
        }
    }

  public static void main(String[] args) {
    int q = 101;

    System.out.println("\n\nExecução do Rabin Karp pesquisado:");
    
    System.out.println("\nTeste 1: ");
    search("ana", "banana", q);

    System.out.println("\nTeste 2: ");
    search("bye", "hello world", q);

    System.out.println("\nTeste 3: ");
    search("pattern", "pattern", q);

    System.out.println("\nTeste 4: ");
    search("$c d#", "a_b$c d#e%f^", q);

    System.out.println("\nTeste 5: ");
    search("muchlongerpattern", "short", q);

    System.out.println("\nTeste 6: ");
    search("sensitive", "CaseSensitiveTest", q);

    System.out.println("\nTeste 7: ");
    search("rabin", "rabin-karp-algorithm", q);

    System.out.println("\nTeste 8: ");
    search("pattern", "search-algorithm-pattern", q);

    System.out.println("\nTeste 9: ");
    search("aa", "aaaaaa", q);

    System.out.println("\nTeste 10: ");
    search("ipsum", "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", q);
  }
}
